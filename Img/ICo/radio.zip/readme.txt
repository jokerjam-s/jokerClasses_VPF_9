Radio.icl : chips and radiosets

These icons are collected by 
sdh-delphi <scooby-doo@bk.ru>

The icons are contained in icon library (ICL) file.
Software for extracting icons from ICL files is available here:
http://www.iconutils.com/

Popular icon editor and icon library manager is ArtIcons.
ArtIcons page: http://www.aha-soft.com/articons/
