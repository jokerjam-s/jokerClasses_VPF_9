Computer icons. Collected by D. Costenco.
This icon collection was created with Aha-soft ArtIcons -
advanced icon editor and icon library manager.
http://www.aha-soft.com